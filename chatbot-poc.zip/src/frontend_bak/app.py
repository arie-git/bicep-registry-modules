from dotenv import load_dotenv
import os
import streamlit as st
import requests
import base64
import json
import time
import logging

load_dotenv()

logging.basicConfig(level=logging.INFO, format="%(asctime)s - %(name)s - %(levelname)s - %(message)s")
logger = logging.getLogger(__name__)

def mask(value: str | None, show: int = 6) -> str:  # <-- fixed '->'
    """Mask sensitive values in logs by showing only the first `show` chars."""
    if not value:
        return ""
    try:
        return value[:show] + "…" + f"({len(value)} chars)"
    except Exception:
        return "«masked»"

# ---- Startup diagnostics (no secrets) ----
logger.info("Starting Streamlit app")
logger.debug({
    "TENANT_ID_present": bool(os.getenv("AZURE_TENANT_ID")),
    "API_BASE_present": bool(os.getenv("API_BASE")),
    "REDIRECT_URI_present": bool(os.getenv("REDIRECT_URI")),
    "CLIENT_ID_FRONTEND_present": bool(os.getenv("AZURE_CLIENT_ID_FRONTEND")),
    "CLIENT_ID_BACKEND_present": bool(os.getenv("AZURE_CLIENT_ID_BACKEND")),
})

TENANT_ID = os.getenv("AZURE_TENANT_ID")
AUTHORITY = f"https://login.microsoftonline.com/{TENANT_ID}"  # (not used here, but OK to keep)

CLIENT_ID_BACKEND = os.getenv("AZURE_CLIENT_ID_BACKEND")
BACKEND_AUD = f"api://{CLIENT_ID_BACKEND}"  # expected audience for your backend API

API_BASE = os.getenv("API_BASE")
REDIRECT_URI = os.getenv("REDIRECT_URI")

logger.info("Auth configuration initialized")
logger.debug({"AUTHORITY": AUTHORITY, "BACKEND_AUD": BACKEND_AUD, "API_BASE": API_BASE, "REDIRECT_URI": REDIRECT_URI})

# ---- Easy Auth helpers (minimal) ----
def _jwt_aud(token: str) -> str | None:  # <-- fixed '->'
    """Decode JWT payload to read 'aud' without extra deps."""
    try:
        payload_b64 = token.split(".")[1]
        padding = "=" * (-len(payload_b64) % 4)
        data = json.loads(base64.urlsafe_b64decode(payload_b64 + padding))
        return data.get("aud")
    except Exception:
        return None

def _base_url() -> str | None:  # <-- fixed '->'
    try:
        from urllib.parse import urlsplit
        url = getattr(st.context, "url", None)
        if not url:
            return None
        parts = urlsplit(url)
        return f"{parts.scheme}://{parts.netloc}"
    except Exception:
        return None

def _login_url_with_scope() -> str | None:  # <-- fixed '->'
    """
    Build a provider login URL for Easy Auth re-login.
    NOTE: The documented URL param is 'post_login_redirect_uri'.
    Prefer adding 'scope=...' in App Service Authentication (authSettingsV2.loginParameters).
    """
    base = _base_url()
    if not base:
        return None
    from urllib.parse import quote
    post = quote(base, safe="")
    # Only include 'post_login_redirect_uri' on the link per docs; scopes are better set in provider loginParameters.  [1](https://learn.microsoft.com/en-us/azure/app-service/configure-authentication-customize-sign-in-out)
    return f"{base}/.auth/login/aad?post_login_redirect_uri={post}"  # <-- '&' not '&amp;'

def _get_access_token_from_initial_headers() -> tuple[str | None, str | None]:  # <-- fixed '->'
    try:
        hdrs = getattr(st.context, "headers", {}) or {}
        lower = {str(k).lower(): v for k, v in hdrs.items()}
    except Exception as e:
        logger.warning(f"st.context.headers unavailable: {e}")
        return None, None

    access = lower.get("x-ms-token-aad-access-token")  # access token only
    expires = lower.get("x-ms-token-aad-expires-on")
    return access, expires

def _get_access_token_via_auth_me() -> tuple[str | None, str | None]:  # <-- fixed '->'
    """
    Call /.auth/me with AppServiceAuthSession cookie to read tokens from the token store.
    """
    base = _base_url()
    cookies = getattr(st.context, "cookies", {}) or {}
    session_cookie = cookies.get("AppServiceAuthSession")

    if not base or not session_cookie:
        logger.debug("Missing base URL or AppServiceAuthSession; cannot call /.auth/me")
        return None, None

    try:
        resp = requests.get(
            f"{base}/.auth/me",
            headers={"Accept": "application/json"},
            cookies={"AppServiceAuthSession": session_cookie},
            timeout=10,
        )
        if resp.status_code != 200:
            logger.debug(f"/.auth/me -> {resp.status_code}: {resp.text[:180]}...")
            return None, None

        identities = resp.json()
        if isinstance(identities, list):
            for ident in identities:
                tok = ident.get("access_token")
                if tok and _jwt_aud(tok) == BACKEND_AUD:
                    logger.info("Found backend-audience token in token store")
                    return tok, ident.get("expires_on")
    except requests.RequestException as e:
        logger.warning(f"/.auth/me request failed: {e}")
    except (ValueError, json.JSONDecodeError) as e:
        logger.warning(f"/.auth/me JSON parse failed: {e}")
    return None, None

def acquire_backend_audience_token() -> tuple[str | None, str | None]:  # <-- fixed '->'
    """
    Try initial headers first; fall back to token store; accept only tokens whose 'aud' equals BACKEND_AUD.
    """
    tok, exp = _get_access_token_from_initial_headers()
    if tok and _jwt_aud(tok) == BACKEND_AUD:
        logger.info("Using backend-audience token from initial headers")
        return tok, exp

    tok, exp = _get_access_token_via_auth_me()
    if tok:
        return tok, exp

    return None, None  # <-- added default

def _safe_json(resp):
    ct = (resp.headers.get("Content-Type") or "").lower()
    logger.debug(f"Response Content-Type: {ct}")
    if "application/json" in ct:
        try:
            return resp.json()
        except (ValueError, json.JSONDecodeError) as e:
            logger.warning(f"JSON decode failed: {e}")
            return None
    return

# ---- Acquire token once, build Authorization header ----
if "easy_auth_token" not in st.session_state or not st.session_state.get("easy_auth_token"):
    token, expires_on = acquire_backend_audience_token()
    if token:
        st.session_state.easy_auth_token = token
        st.session_state.easy_auth_expires_on = expires_on
        logger.info(f"Cached Easy Auth token (aud={_jwt_aud(token)}): {mask(token)}")
    else:
        login_url = _login_url_with_scope()
        st.error(
            "You're signed in, but we don't have an access token for this app's API scope.\n\n"
            "Click below to sign in again and grant the required scope."
        )
        if login_url:
            st.link_button("Sign in with API scope", login_url)
        st.stop()

token = st.session_state.get("easy_auth_token")
headers = {"Authorization": f"Bearer {token}", "Accept": "application/json"}
logger.info("Authorization header set for outgoing requests")
logger.debug({"Authorization_preview": f"Bearer {mask(token)}"})

def _truncate(text: str | None, max_len: int = 200) -> str:  # <-- fixed '->'
    """Return a shortened preview for logs/UI without leaking large bodies."""
    if text is None:
        return ""
    s = str(text)
    return s if len(s) <= max_len else s[:max_len] + "…"

# ---- Optional: compact debug UI ----
with st.expander("Auth Debug"):
    st.write("Has access token:", bool(token))
    st.write("Token audience:", _jwt_aud(token))
    st.write("Expires on:", st.session_state.get("easy_auth_expires_on"))

# ---- Subscriptions section ----
st.subheader("Subscriptions")
status_placeholder = st.empty()

if st.button("Load Subscriptions"):
    url = f"{API_BASE.rstrip('/')}/subscriptions"
    logger.info(f"GET {url}")
    start = time.perf_counter()
    try:
        resp = requests.get(url, headers=headers, timeout=30)
        elapsed_ms = int((time.perf_counter() - start) * 1000)
        corr_id = (
            resp.headers.get("x-ms-request-id")
            or resp.headers.get("request-id")
            or resp.headers.get("X-Request-Id")
        )
        logger.info(f"GET /subscriptions -> {resp.status_code} in {elapsed_ms} ms")
        if corr_id:
            logger.debug(f"Correlation ID: {corr_id}")

        status_placeholder.info(f"Response: {resp.status_code} ({elapsed_ms} ms)")

        if resp.status_code == 200:
            data = _safe_json(resp)
            st.write(data if data is not None else resp.text)
        else:
            json_body = _safe_json(resp)
            body_preview = json_body if json_body is not None else _truncate(resp.text)
            logger.error(f"Subscriptions request failed: status={resp.status_code}, body={body_preview}")
            st.error(json_body if json_body is not None else f"{resp.status_code} {resp.reason}\n\n{body_preview}")
    except requests.RequestException as e:
        logger.exception(f"Subscriptions request error: {e}")


# LLM Chat
st.subheader("Policy Compliance Assistant")
logger.debug("Rendered Policy Compliance Assistant subheader")
if "messages" not in st.session_state:
    st.session_state.messages = []
    logger.debug("Initialized session_state.messages")

search_text = st.text_input("Knowledge base context")
control_id = st.text_input("Policy Control ID")
logger.debug({
    "search_text_len": len(search_text or ""),
    "control_id_present": bool(control_id),
})

if st.button("Start Chat"):
    url = f"{API_BASE}/llm/init"
    payload = {"search_text": search_text, "control_id": control_id}
    logger.info(f"POST {url}")
    logger.debug(
        {
            "payload_keys": list(payload.keys()),
            "search_text_len": len(search_text or ""),
            "control_id": control_id,
        }
    )
    start = time.perf_counter()
    try:
        resp = requests.post(url, json=payload, headers=headers, timeout=60)
        elapsed_ms = int((time.perf_counter() - start) * 1000)
        corr_id = resp.headers.get("x-ms-request-id") or resp.headers.get("request-id")
        logger.info(f"POST /llm/init -> {resp.status_code} in {elapsed_ms} ms")
        if corr_id:
            logger.debug(f"Correlation ID: {corr_id}")

        if resp.status_code == 200:
            result = _safe_json(resp) or {}
            logger.debug(f"Init response preview: {_truncate(str(result))}")
            st.session_state.messages = result.get("messages", [])
            logger.debug(f"Initialized messages count: {len(st.session_state.messages or [])}")
            st.write(result.get("answer", ""))
        else:
            err_preview = _safe_json(resp) or resp.text
            logger.error(
                f"Init failed: status={resp.status_code}, body={_truncate(str(err_preview))}"
            )
            # show body if JSON for easier debugging
            try:
                st.error(resp.json())
            except ValueError:
                st.error(f"{resp.status_code} {resp.reason}\n\n{_truncate(resp.text)}")
    except requests.RequestException as e:
        logger.exception(f"Init request error: {e}")
        st.error("Failed to start chat.")

user_input = st.text_input("Your question")
logger.debug({"user_input_len": len(user_input or "")})
if st.button("Send"):
    url = f"{API_BASE}/llm/chat"
    payload = {"messages": st.session_state.messages, "user_input": user_input}
    logger.info(f"POST {url}")
    logger.debug(
        {
            "messages_count": len(st.session_state.messages or []),
            "user_input_len": len(user_input or ""),
        }
    )
    start = time.perf_counter()
    try:
        resp = requests.post(url, json=payload, headers=headers, timeout=60)
        elapsed_ms = int((time.perf_counter() - start) * 1000)
        corr_id = resp.headers.get("x-ms-request-id") or resp.headers.get("request-id")
        logger.info(f"POST /llm/chat -> {resp.status_code} in {elapsed_ms} ms")
        if corr_id:
            logger.debug(f"Correlation ID: {corr_id}")

        if resp.status_code == 200:
            result = _safe_json(resp) or {}
            logger.debug(f"Chat response preview: {_truncate(str(result))}")
            st.session_state.messages = result.get("messages", [])
            logger.debug(f"Updated messages count: {len(st.session_state.messages or [])}")
            st.write(result.get("answer", ""))
        else:
            err_preview = _safe_json(resp) or resp.text
            logger.error(
                f"Chat failed: status={resp.status_code}, body={_truncate(str(err_preview))}"
            )
            try:
                st.error(resp.json())
            except ValueError:
                st.error(f"{resp.status_code} {resp.reason}\n\n{_truncate(resp.text)}")
    except requests.RequestException as e:
               logger.exception(f"Chat request error: {e}")
