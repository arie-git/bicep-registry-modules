### TODO
- Integrate App Service Authentication into code
- App service deployment pipeline
- Front end with DRCP policy retrieval
- Global design template / Draft
- Indexing configuration of AI Search
- Capture indexing configuration in code
- ???

### How to deploy manually

`az login`

`az account set -s AM-CCC-ENV24083-DEV`

DEFAULT values:

`az deployment sub create --location swedencentral -f .\infra\main.bicep --name cccchatbotpoc`

### Approval shared private links
You should first request in DRDC portal to whitelist shared private link resource id. Contact an AM IRSO and explain that you are using DRCP Azure Component. Most importantly the risk / CIA rating. After this, wait for approval and then you can proceed with the below.

# Get the access token
token=$(az account get-access-token --resource https://management.azure.com --query accessToken -o tsv)

# Send the PUT request with curl
curl -X PUT "https://management.azure.com/subscriptions/3266700d-4b59-4135-8173-9fff57719eb2/resourceGroups/drcpchat01-dev-swedencentral-rg/providers/Microsoft.Storage/storageAccounts/s2drcpchat01devsecsta/privateEndpointConnections/s2drcpchat01devsecsta.38734af7-bf6b-495b-9ec4-2d5cf0fd8c3d?api-version=2025-06-01" \
  -H "Authorization: Bearer $token" \
  -H "Content-Type: application/json" \
  -d '{
    "properties": {
      "privateLinkServiceConnectionState": {
        "status": "Approved",
        "description": "Manual approval required"
      },
      "privateEndpoint": {
        "id": "/subscriptions/92f6e104-9940-47cf-8b40-665f3a7bee9d/resourceGroups/azstibk/providers/Microsoft.Network/privateEndpoints/s2drcpchat01devsecsta-shrdplr-01"
      }
    }
  }'

# Second PUT request (Cognitive Services PEP)
curl -X PUT "https://management.azure.com/subscriptions/3266700d-4b59-4135-8173-9fff57719eb2/resourceGroups/drcpchat01-dev-swedencentral-rg/providers/Microsoft.Storage/storageAccounts/s2drcpchat01devsecsta/privateEndpointConnections/s2drcpchat01devsecsta.31b1f4e7-d145-480c-a964-29c46118c3a5?api-version=2025-06-01" \
  -H "Authorization: Bearer $token" \
  -H "Content-Type: application/json" \
  -d '{
    "properties": {
      "privateLinkServiceConnectionState": {
        "status": "Approved",
        "description": "Manual approval required"
      },
      "privateEndpoint": {
        "id": "/subscriptions/92f6e104-9940-47cf-8b40-665f3a7bee9d/resourceGroups/azstibk/providers/Microsoft.Network/privateEndpoints/s2drcpchat01devsecsta-shrdplr-02"
      }
    }
  }'

# Third PUT request (Cognitive Services PEP)
curl -X PUT "https://management.azure.com/subscriptions/3266700d-4b59-4135-8173-9fff57719eb2/resourceGroups/drcpchat01-dev-swedencentral-rg/providers/Microsoft.CognitiveServices/accounts/s2drcpchat01devseccsapoc02/privateEndpointConnections/s2drcpchat01devseccsa-shrdplr-03.30ea1091-92df-4924-9414-103856381bae?api-version=2024-10-01" \
  -H "Authorization: Bearer $token" \
  -H "Content-Type: application/json" \
  -d '{
    "properties": {
      "privateLinkServiceConnectionState": {
        "status": "Approved",
        "description": "Manual approval required"
      },
      "privateEndpoint": {
        "id": "/subscriptions/92f6e104-9940-47cf-8b40-665f3a7bee9d/resourceGroups/azstibk/providers/Microsoft.Network/privateEndpoints/s2drcpchat01devseccsa-shrdplr-03"
      }
    }
  }'

### Deploying your web app

# zip your files
`zip -r sample.zip .`
# this one actualy works:
`az webapp deployment source config-zip --resource-group drcpchat01-dev-swedencentral-rg --name s2drcpchat01devsecapp01 --src sample.zip`